  <!-- *****************************
  Page Name  : current page name 
  Author     : Your Name 
  Your URL   : ocelot-aul.fiu/~____
  Course     : CGS 4854 session, date, and time
  Program #  : Assignment #
  Purpose    : Describe what this page does 

  Due Date   : MM/DD/YYYY 

  Certification: 

  I hereby certify that this work is my own and none of it is the work of any other person. 

  ..........{ your full name }..........
  ***************************** -->

  <nav>
      <ul>
          <li><a href="">Home</a></li>
          <li><a href="#">Program 1</a></li>
          <li><a href="#">Program 2</a></li>
          <li><a href="program3.php">Program 3</a></li>
      </ul>
  </nav>