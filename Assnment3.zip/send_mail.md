If you are on windows will work

https://php.tutorials24x7.com/blog/how-to-use-sendmail-on-windows-to-send-email-using-php