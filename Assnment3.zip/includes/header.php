<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Program 3</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body style="text-align: center">
    <h4>
        ====This is a Teaching Website====
    </h4>
    <br>
    <h6>
        Joe Smith
    </h6>
    <br>
    <hr>

    </pre>

    <nav>
        <ul style="display:flex; align-items: center">
            <li><a href="#">Home</a></li>
            <li><a href="#">Program 1</a></li>
            <li><a href="#">Program 2</a></li>
            <li><a href="program3.php">Program 3</a></li>
        </ul>
    </nav>
    <br>
</body>

</html>
<pre>